"use node";
import { action } from "./_generated/server";
import { v } from "convex/values";

/**
 * Verifies admin credentials against ADMIN_USERNAME + ADMIN_PASSWORD env vars.
 * Returns a short-lived session token (a signed timestamp) stored only in the
 * browser's sessionStorage — no DB rows, no user accounts.
 */
export const verifyAdmin = action({
  args: {
    username: v.string(),
    password: v.string(),
  },
  handler: async (_ctx, args): Promise<{ ok: boolean; token?: string }> => {
    const expectedUser = process.env.ADMIN_USERNAME;
    const expectedPass = process.env.ADMIN_PASSWORD;

    if (!expectedUser || !expectedPass) {
      return { ok: false };
    }

    const usernameMatch = args.username === expectedUser;
    const passwordMatch = args.password === expectedPass;

    if (!usernameMatch || !passwordMatch) {
      // Constant-time-ish: always check both
      return { ok: false };
    }

    // Token = base64( username + ":" + timestamp + ":" + secret_fragment )
    // The client stores this and sends it back; we re-verify on sensitive ops
    // by checking the secret fragment. Good enough for a single-admin tool.
    const secret = process.env.ADMIN_PASSWORD ?? "";
    const payload = `${args.username}:${Date.now()}:${secret.slice(0, 8)}`;
    const token = Buffer.from(payload).toString("base64");

    return { ok: true, token };
  },
});

/**
 * Validates a previously-issued admin token.
 * Tokens expire after 8 hours.
 */
export const validateAdminToken = action({
  args: { token: v.string() },
  handler: async (_ctx, args): Promise<{ valid: boolean }> => {
    try {
      const secret = process.env.ADMIN_PASSWORD ?? "";
      const decoded = Buffer.from(args.token, "base64").toString("utf8");
      const parts = decoded.split(":");
      if (parts.length < 3) return { valid: false };

      const [username, tsStr, secretFragment] = parts;
      const expectedUser = process.env.ADMIN_USERNAME;

      if (username !== expectedUser) return { valid: false };
      if (secretFragment !== secret.slice(0, 8)) return { valid: false };

      const ts = parseInt(tsStr, 10);
      const eightHours = 8 * 60 * 60 * 1000;
      if (Date.now() - ts > eightHours) return { valid: false };

      return { valid: true };
    } catch {
      return { valid: false };
    }
  },
});
