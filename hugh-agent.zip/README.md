# hugh-agent

**H.U.G.H. Holographic Satellite Node**

A lightweight HTTP execution bridge for the H.U.G.H. infrastructure. It allows H.U.G.H. (on Convex) to securely execute shell commands and scripts across your distributed lab environments.

## Features

- **HTTP Execution Bridge:** Execute shell commands via `/exec`.
- **Spontaneous Tunneling:** Automatic Cloudflare Tunnel creation.
- **Node Registration:** Automatically registers with the Convex `agentRegistry`.
- **Self-Repair:** Supports architectural updates via signed `/update` scripts.
- **Cross-Platform:** Native support for macOS (zsh) and Linux (bash).

## Installation

```bash
cd hugh-agent
npm install
npm link # To use the 'hugh-agent' command globally
```

## Usage

### 1. Configure
Copy `.env.example` to `.env` and set your secrets:
```bash
cp .env.example .env
```

### 2. Start Agent
```bash
hugh-agent start --tunnel
```

### 3. Verify
```bash
curl -H "X-Agent-Secret: your-secret" http://localhost:7734/info
```

## Architecture

```
H.U.G.H. (Convex) <---> Cloudflare Tunnel <---> hugh-agent (Node Node)
```

## Security

- Binds to `127.0.0.1` only.
- Requires `X-Agent-Secret` for all execution endpoints.
- All commands logged to Convex `kvmCommandLog`.
- Agent secrets are hashed on the Convex side.
